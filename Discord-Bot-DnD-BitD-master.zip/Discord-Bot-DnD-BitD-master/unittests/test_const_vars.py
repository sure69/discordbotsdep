import os

unit_test_save_file_name = "unit_test"
test_user_id: str = "0"
test_user_id_int: int = 0
test_char_tag: str = "test"
test_discord_username: str = "TEST_DISCORD_USERNAME"
test_discord_username2: str = "TEST_DISCORD_USERNAME2"
template_save_folder_relative_path: str = os.sep.join(["test_saves"])


