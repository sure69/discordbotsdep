entanglement_sorting_table = [
    [
        ["The Usual Suspects", "Diplomatic Incident"],
        ["Squanderers", "Unexpected Expenses"],
        ["Gang Trouble", "Pushy Friends"],
        ["Rivals", "Cohort Tension"],
        ["Unquiet Dead", "Crisis of Vice"],
        ["Cooperation", "Unexpected Complication"]
    ],
    [
        ["Gang Trouble", "Enraged Citizenry"],
        ["Search Warrant", "Accosted by Spirit Guards"],
        ["Questioning", "Crisis of Faith", "Haunted Claim"],
        ["Unquiet Dead", "Casual Racism", "Unfair Competition"],
        ["Reprisals", "Civil War", "Settling of Scores"],
        ["Show of Force", "Arrested Cohort"],
    ],
    [
        ["Interrogation", "Helping the Poor"],
        ["Robbery", "Overambitious Lackey"],
        ["Flipped", "Tax Evasion Charge"],
        ["Demonic Notice", "Crew Trouble", "Hostile Magistrate"],
        ["Show of Force", "War", "Ambitious Lackey"],
        ["Arrest", "Mayhem", "Incarcerated Cohort"]
    ]
]
