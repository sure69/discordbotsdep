class BladesCommandException(Exception):
    pass
