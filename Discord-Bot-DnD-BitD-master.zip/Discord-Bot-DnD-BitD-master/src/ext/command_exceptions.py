

class CommandException(Exception):
    pass